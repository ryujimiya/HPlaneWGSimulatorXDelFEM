using System;
using System.Collections.Generic;
using System.Text;

namespace LisysTest
{
    using NUnit.Framework;
    using KrdLab.Lisys;
    using KrdLab.Lisys.IO;
    using System.IO;
    using KrdLab.Lisys.Method;
    using KrdLab.Lisys.Testing;

    /// <summary>
    /// NUnit��p�����e�X�g
    /// </summary>
    [TestFixture]
    public class LisysTest
    {
        [Test]
        public void Test()
        {
            Assert.IsTrue(true);
        }
    }
}
